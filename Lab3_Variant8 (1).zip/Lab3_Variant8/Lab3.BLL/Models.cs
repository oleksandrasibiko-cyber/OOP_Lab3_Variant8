namespace Lab3.BLL.Models;

// Власні моделі BLL: DAL-сутності не виходять за межі рівня доступу до даних.
public record StudentModel(string Surname, string FirstName, int Course, string StudentId, DateTime BirthDate);
public record StringModel(string Value);
public record BakerModel(string Name, int ExperienceYears);
public record EntrepreneurModel(string Name, string Business);
