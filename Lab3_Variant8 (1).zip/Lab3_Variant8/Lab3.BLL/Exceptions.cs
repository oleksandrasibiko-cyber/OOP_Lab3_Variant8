namespace Lab3.BLL;

public class StudentDataException : Exception
{
    public StudentDataException(string message) : base(message) { }
}
