using Lab3.BLL.Models;
using Lab3.DAL;
using Lab3.DAL.Entities;
using Lab3.DAL.Serialization;

namespace Lab3.BLL;

public class EntityService
{
    private readonly EntityContext _context = new();

    public void SaveStudents(string path, SerializationKind kind, List<StudentModel> models)
    {
        Validate(models);
        var entities = models.Select(ToEntity).ToList();
        _context.Write(path, entities, EntityContext.StudentProvider(kind));
    }

    public List<StudentModel> LoadStudents(string path, SerializationKind kind)
    {
        try { return _context.Read(path, EntityContext.StudentProvider(kind)).Select(ToModel).ToList(); }
        catch (Exception ex) when (ex is IOException or InvalidDataException or FormatException or System.Xml.XmlException or System.Text.Json.JsonException)
        { throw new StudentDataException($"Не вдалося прочитати файл: {ex.Message}"); }
    }

    public int CountFourthYearSpringStudents(List<StudentModel> students) =>
        students.Count(s => s.Course == 4 && s.BirthDate.Month is >= 3 and <= 5);

    public void SaveStrings(string path, SerializationKind kind, List<StringModel> strings)
    {
        var entities = strings.Select(s => new StringEntity { Value = s.Value }).ToList();
        _context.Write(path, entities, EntityContext.StringProvider(kind));
    }

    public List<StringModel> LoadStrings(string path, SerializationKind kind) =>
        _context.Read(path, EntityContext.StringProvider(kind)).Select(s => new StringModel(s.Value)).ToList();

    public static string DescribeString(StringModel item) =>
        $"Рядок: \"{item.Value}\" | Довжина: {item.Value.Length}";

    public static int FindCharacter(StringModel item, char symbol) => item.Value.IndexOf(symbol);
    public static StringModel ReverseOrder(StringModel item) => new(new string(item.Value.Reverse().ToArray()));
    public static StringModel Append(StringModel first, string second) => new(first.Value + second);

    private static void Validate(List<StudentModel> students)
    {
        if (students.Any(s => string.IsNullOrWhiteSpace(s.Surname) ||
                              string.IsNullOrWhiteSpace(s.FirstName) ||
                              s.Course is < 1 or > 6 ||
                              string.IsNullOrWhiteSpace(s.StudentId) ||
                              s.BirthDate > DateTime.Today))
            throw new StudentDataException("Перевірте дані студентів: поля мають бути заповнені, курс 1–6, дата народження не може бути в майбутньому.");
    }
    private static StudentEntity ToEntity(StudentModel s) => new()
    { Surname = s.Surname, FirstName = s.FirstName, Course = s.Course, StudentId = s.StudentId, BirthDate = s.BirthDate };
    private static StudentModel ToModel(StudentEntity s) =>
        new(s.Surname, s.FirstName, s.Course, s.StudentId, s.BirthDate);
}
