namespace Lab3.DAL.Entities;

// Сутності предметної області зберігаються тільки на рівні DAL.
public class StringEntity
{
    public string Value { get; set; } = "";
    public int Length => Value.Length;
}

public class StudentEntity
{
    public string Surname { get; set; } = "";
    public string FirstName { get; set; } = "";
    public int Course { get; set; }
    public string StudentId { get; set; } = "";
    public DateTime BirthDate { get; set; }
}

public class BakerEntity
{
    public string Name { get; set; } = "";
    public int ExperienceYears { get; set; }
}

public class EntrepreneurEntity
{
    public string Name { get; set; } = "";
    public string Business { get; set; } = "";
}
