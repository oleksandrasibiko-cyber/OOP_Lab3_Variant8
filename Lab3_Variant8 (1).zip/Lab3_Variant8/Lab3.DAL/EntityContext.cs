using Lab3.DAL.Entities;
using Lab3.DAL.Serialization;
using System.Globalization;

namespace Lab3.DAL;

public class EntityContext
{
    public List<T> Read<T>(string path, IDataProvider<T> provider) =>
        File.Exists(path) ? provider.Load(path) : new List<T>();

    public void Write<T>(string path, List<T> items, IDataProvider<T> provider) =>
        provider.Save(path, items);

    public void Delete(string path)
    {
        if (File.Exists(path)) File.Delete(path);
    }

    public static IDataProvider<StringEntity> StringProvider(SerializationKind kind) => kind switch
    {
        SerializationKind.Json => new JsonProvider<StringEntity>(),
        SerializationKind.Xml => new XmlProvider<StringEntity>(),
        SerializationKind.Binary => new BinaryProvider<StringEntity>(
            x => new[] { x.Value }, f => new StringEntity { Value = f[0] }),
        SerializationKind.Custom => new CustomProvider<StringEntity>(
            x => new[] { x.Value }, f => new StringEntity { Value = f[0] }),
        _ => throw new ArgumentOutOfRangeException(nameof(kind))
    };

    public static IDataProvider<StudentEntity> StudentProvider(SerializationKind kind) => kind switch
    {
        SerializationKind.Json => new JsonProvider<StudentEntity>(),
        SerializationKind.Xml => new XmlProvider<StudentEntity>(),
        SerializationKind.Binary => new BinaryProvider<StudentEntity>(StudentToFields, FieldsToStudent),
        SerializationKind.Custom => new CustomProvider<StudentEntity>(StudentToFields, FieldsToStudent),
        _ => throw new ArgumentOutOfRangeException(nameof(kind))
    };

    private static string[] StudentToFields(StudentEntity s) => new[]
    {
        s.Surname, s.FirstName, s.Course.ToString(CultureInfo.InvariantCulture),
        s.StudentId, s.BirthDate.ToString("O", CultureInfo.InvariantCulture)
    };
    private static StudentEntity FieldsToStudent(string[] f) => new()
    {
        Surname = f[0], FirstName = f[1], Course = int.Parse(f[2], CultureInfo.InvariantCulture),
        StudentId = f[3], BirthDate = DateTime.Parse(f[4], CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind)
    };
}
