using System.Text;
using System.Text.Json;
using System.Xml.Serialization;

namespace Lab3.DAL.Serialization;

public enum SerializationKind { Binary = 1, Xml = 2, Json = 3, Custom = 4 }

public interface IDataProvider<T>
{
    void Save(string path, List<T> items);
    List<T> Load(string path);
}

public sealed class JsonProvider<T> : IDataProvider<T>
{
    private readonly JsonSerializerOptions _options = new() { WriteIndented = true };
    public void Save(string path, List<T> items) =>
        File.WriteAllText(path, JsonSerializer.Serialize(items, _options), Encoding.UTF8);
    public List<T> Load(string path) =>
        JsonSerializer.Deserialize<List<T>>(File.ReadAllText(path, Encoding.UTF8)) ?? new();
}

public sealed class XmlProvider<T> : IDataProvider<T>
{
    public void Save(string path, List<T> items)
    {
        using var stream = File.Create(path);
        new XmlSerializer(typeof(List<T>)).Serialize(stream, items);
    }
    public List<T> Load(string path)
    {
        using var stream = File.OpenRead(path);
        return (List<T>?)new XmlSerializer(typeof(List<T>)).Deserialize(stream) ?? new();
    }
}

// Бінарний формат реалізовано через BinaryWriter/BinaryReader.
// Це сумісний із сучасним .NET спосіб запису примітивних значень у двійковий файл.
public sealed class BinaryProvider<T> : IDataProvider<T>
{
    private readonly Func<T, string[]> _writeFields;
    private readonly Func<string[], T> _readFields;
    public BinaryProvider(Func<T, string[]> writeFields, Func<string[], T> readFields)
    { _writeFields = writeFields; _readFields = readFields; }

    public void Save(string path, List<T> items)
    {
        using var writer = new BinaryWriter(File.Create(path), Encoding.UTF8);
        writer.Write(items.Count);
        foreach (var item in items)
        {
            var fields = _writeFields(item);
            writer.Write(fields.Length);
            foreach (var field in fields) writer.Write(field);
        }
    }
    public List<T> Load(string path)
    {
        using var reader = new BinaryReader(File.OpenRead(path), Encoding.UTF8);
        int count = reader.ReadInt32();
        if (count < 0 || count > 100000) throw new InvalidDataException("Некоректна кількість записів.");
        var result = new List<T>();
        for (int i = 0; i < count; i++)
        {
            int fieldCount = reader.ReadInt32();
            if (fieldCount < 0 || fieldCount > 100) throw new InvalidDataException("Некоректний запис.");
            var fields = new string[fieldCount];
            for (int j = 0; j < fieldCount; j++) fields[j] = reader.ReadString();
            result.Add(_readFields(fields));
        }
        return result;
    }
}

// Користувацька серіалізація: власний текстовий формат з екрануванням роздільника.
public sealed class CustomProvider<T> : IDataProvider<T>
{
    private readonly Func<T, string[]> _writeFields;
    private readonly Func<string[], T> _readFields;
    public CustomProvider(Func<T, string[]> writeFields, Func<string[], T> readFields)
    { _writeFields = writeFields; _readFields = readFields; }

    public void Save(string path, List<T> items)
    {
        var lines = items.Select(x => string.Join("|", _writeFields(x).Select(Escape)));
        File.WriteAllLines(path, lines, Encoding.UTF8);
    }
    public List<T> Load(string path) =>
        File.ReadAllLines(path, Encoding.UTF8).Select(line => _readFields(Split(line))).ToList();

    private static string Escape(string value) => value.Replace("\\", "\\\\").Replace("|", "\\p").Replace("\n", "\\n");
    private static string[] Split(string line)
    {
        var fields = new List<string>(); var current = new StringBuilder();
        for (int i = 0; i < line.Length; i++)
        {
            if (line[i] == '\\' && i + 1 < line.Length)
            {
                char next = line[++i];
                current.Append(next == 'n' ? '\n' : next == 'p' ? '|' : next);
            }
            else if (line[i] == '|') { fields.Add(current.ToString()); current.Clear(); }
            else current.Append(line[i]);
        }
        fields.Add(current.ToString());
        return fields.ToArray();
    }
}

public static class ProviderFactory
{
    public static IDataProvider<T> Create<T>(SerializationKind kind)
    {
        if (kind == SerializationKind.Json) return new JsonProvider<T>();
        if (kind == SerializationKind.Xml) return new XmlProvider<T>();
        throw new NotSupportedException("Для цього типу використовуйте спеціалізований Binary/Custom provider.");
    }
}
