namespace Lab3.PL;

// Модель представлення PL відокремлена від моделей BLL і сутностей DAL.
public record StudentInput(string Surname, string FirstName, int Course, string StudentId, DateTime BirthDate);
