using Lab3.BLL;
using Lab3.BLL.Models;
using Lab3.DAL.Serialization;
using System.Globalization;

namespace Lab3.PL;

public class Menu
{
    private readonly EntityService _service = new();

    public void MainMenu()
    {
        while (true)
        {
            Console.WriteLine("\n=== Лабораторна робота 3.3 — Варіант 8 ===");
            Console.WriteLine("1. Частина 1 — робота з рядками та серіалізація");
            Console.WriteLine("2. Частина 2 — трирівнева архітектура, студенти");
            Console.WriteLine("0. Вихід");
            Console.Write("Ваш вибір: ");
            switch (Console.ReadLine())
            {
                case "1": StringMenu(); break;
                case "2": StudentMenu(); break;
                case "0": return;
                default: Console.WriteLine("Невірний пункт меню."); break;
            }
        }
    }

    private void StringMenu()
    {
        var items = new List<StringModel>
        {
            new("Об'єктно-орієнтоване програмування"),
            new("Мова C#"),
            new("Серіалізація"),
            new("Варіант 8")
        };
        Console.WriteLine("\nПочаткові 4 рядки:");
        PrintStrings(items);
        Console.Write("Введіть символ для пошуку в першому рядку: ");
        var input = Console.ReadLine() ?? "";
        if (input.Length > 0)
        {
            int index = EntityService.FindCharacter(items[0], input[0]);
            Console.WriteLine(index >= 0 ? $"Символ знайдено на позиції {index}." : "Символ не знайдено.");
        }
        Console.WriteLine($"Рядок у зворотному порядку: {EntityService.ReverseOrder(items[1]).Value}");
        items[2] = EntityService.Append(items[2], " у C#");
        Console.WriteLine($"Після додавання: {items[2].Value}");

        Console.WriteLine("\nТип серіалізації: 1-Бінарна 2-XML 3-JSON 4-Користувацька");
        var kind = ReadKind();
        string path = AskPath("strings");
        _service.SaveStrings(path, kind, items);
        var restored = _service.LoadStrings(path, kind);
        Console.WriteLine($"\nВідновлено з файлу {path}:");
        PrintStrings(restored);
        Console.WriteLine("Порівняння: масив/список після десеріалізації містить ті самі 4 рядки.");
        Console.WriteLine("Натисніть Enter...");
        Console.ReadLine();
    }

    private void StudentMenu()
    {
        Console.WriteLine("\n1. Додати демонстраційні дані (4 студенти)");
        Console.WriteLine("2. Ввести студентів вручну");
        Console.Write("Ваш вибір: ");
        var choice = Console.ReadLine();
        var students = choice == "2" ? ReadStudents() : SampleStudents();
        Console.WriteLine("\nДані студентів:");
        PrintStudents(students);
        Console.WriteLine("\nТип серіалізації: 1-Бінарна 2-XML 3-JSON 4-Користувацька");
        var kind = ReadKind();
        string path = AskPath("students");
        try
        {
            _service.SaveStudents(path, kind, students);
            var restored = _service.LoadStudents(path, kind);
            int count = _service.CountFourthYearSpringStudents(restored);
            Console.WriteLine($"\nКількість студентів 4-го курсу, народжених навесні: {count}");
            Console.WriteLine("Знайдені студенти:");
            PrintStudents(restored.Where(s => s.Course == 4 && s.BirthDate.Month is >= 3 and <= 5).ToList());
        }
        catch (StudentDataException ex) { Console.WriteLine($"Помилка даних: {ex.Message}"); }
        Console.WriteLine("\nДодаткові сутності варіанта: Baker, Entrepreneur.");
        Console.WriteLine("Додаткова навичка: стрибати з парашутом.");
        Console.WriteLine("Натисніть Enter...");
        Console.ReadLine();
    }

    private static List<StudentModel> SampleStudents() => new()
    {
        new("Шевченко", "Анна", 4, "ST-001", new DateTime(2004, 3, 15)),
        new("Коваленко", "Іван", 4, "ST-002", new DateTime(2003, 7, 20)),
        new("Мельник", "Олена", 3, "ST-003", new DateTime(2005, 4, 2)),
        new("Бондар", "Максим", 4, "ST-004", new DateTime(2004, 5, 9))
    };

    private static List<StudentModel> ReadStudents()
    {
        int count = ReadInt("Кількість студентів: ", 1, 1000);
        var list = new List<StudentModel>();
        for (int i = 0; i < count; i++)
        {
            Console.WriteLine($"\nСтудент #{i + 1}");
            Console.Write("Прізвище: "); string surname = Console.ReadLine() ?? "";
            Console.Write("Ім'я: "); string name = Console.ReadLine() ?? "";
            int course = ReadInt("Курс (1–6): ", 1, 6);
            Console.Write("Студентський квиток: "); string id = Console.ReadLine() ?? "";
            DateTime birth;
            while (true)
            {
                Console.Write("Дата народження (дд.мм.рррр): ");
                if (DateTime.TryParseExact(Console.ReadLine(), "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out birth)) break;
                Console.WriteLine("Неправильний формат дати.");
            }
            list.Add(new(surname, name, course, id, birth));
        }
        return list;
    }

    private static SerializationKind ReadKind()
    {
        while (true)
        {
            Console.Write("Ваш вибір: ");
            if (int.TryParse(Console.ReadLine(), out int n) && n is >= 1 and <= 4) return (SerializationKind)n;
            Console.WriteLine("Введіть число від 1 до 4.");
        }
    }
    private static string AskPath(string defaultName)
    {
        Console.Write($"Ім'я/шлях файлу (Enter — {defaultName}): ");
        var path = Console.ReadLine();
        return string.IsNullOrWhiteSpace(path) ? $"{defaultName}.dat" : path;
    }
    private static int ReadInt(string prompt, int min, int max)
    {
        while (true)
        {
            Console.Write(prompt);
            if (int.TryParse(Console.ReadLine(), out int value) && value >= min && value <= max) return value;
            Console.WriteLine($"Введіть число від {min} до {max}.");
        }
    }
    private static void PrintStrings(IEnumerable<StringModel> items)
    {
        int i = 1;
        foreach (var s in items) Console.WriteLine($"{i++}. {EntityService.DescribeString(s)}");
    }
    private static void PrintStudents(IEnumerable<StudentModel> items)
    {
        foreach (var s in items)
            Console.WriteLine($"{s.Surname} {s.FirstName}, курс: {s.Course}, квиток: {s.StudentId}, дата народження: {s.BirthDate:dd.MM.yyyy}");
    }
}
