using Lab3.PL;

new Menu().MainMenu();
